%% CRD algorithm phase I

function [U, s, Js, Deltas, Iter] = CRD_P1(A, B, W, alpha, beta, n, k, MaxIter, epsilon)

%% Initialization

rand('seed',1000);

Unew = rand(n,k);
Unew = bsxfun(@rdivide, Unew, sum(Unew,1)+eps);

snew = rand(k,1);
snew = snew/sum(snew);

% [ia1, ia2, Anz] = find(A);
% [ib1, ib2, Bnz] = find(B);
% [iw1, iw2, Wnz] = find(W);

% J1 = Obj(ia1, ia2, Anz, ib1, ib2, Bnz, iw1, iw2, Wnz, Unew, snew, alpha, beta);

Iter = 1;
J1 = 0;
Js = J1;
Delta = 99999;
Deltas = [];

%% Iteration

while Delta > epsilon && Iter <= MaxIter
    
    % Update U
    
    U = Unew;
    Unew = UpdateU(A, B, W, Unew, snew, alpha, beta);
    
    % Update s
    
    s = snew;
    snew = UpdateS(B, W, Unew, snew, beta);
    
    % Convergence evaluation
    
%     J2 = Obj(ia1, ia2, Anz, ib1, ib2, Bnz, iw1, iw2, Wnz, Unew, snew, alpha, beta);
%     Delta = abs(J1 - J2);
%     Js = [Js, J2];
%     J1 = J2;
    
    Delta_u = abs(Unew-U);
    Delta_u = sum(Delta_u(:));
    
    Delta_s = abs(snew-s);
    Delta_s = sum(Delta_s(:));
    
    Delta = max([Delta_u,Delta_s]);
    
    Deltas = [Deltas, Delta];
    Iter = Iter + 1;
    
end

U = Unew;
s = snew;

end