%% CRD algorithm phase II

function [E, Js, Deltas, Iter] = CRD_P2(H, B, C, U, tau, n, k, MaxIter, epsilon)

%% Initialization

Enew = ones(n,k);

B = B/sqrt(trace((B')*B));

% Convergence parameter

Iter = 1;
% J1 = Obj(H, B, C, U, Enew, tau);
J1 = 0;
Js = J1;
Delta = 99999;
Deltas = [];

%% Iteration

while Delta > epsilon && Iter <= MaxIter
    
    % Update E
    
    E = Enew;
    Enew = UpdateE(H, B, C, U, Enew, tau);
    
    % Convergence evaluation
    
%     J2 = Obj(H, B, C, U, Enew, tau);
%     Delta = J1 - J2;
%     Js = [Js, J2];
%     J1 = J2;
    
    Delta = abs(Enew-E);
    Delta = sum(Delta(:));
    
    Deltas = [Deltas, Delta];
    Iter = Iter + 1;
    
end

E = Enew;

end

% %% Objective function
% 
% function ObjVal = Obj(H, B, C, U, E, tau)
% 
% UE = U.*E;
% HUE = H*UE;
% 
% ObjVal = norm((HUE*(HUE')).*C - B, 'fro')^2 + tau*sum(E(:));
% 
% end