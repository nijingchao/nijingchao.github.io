%% Calculate AUC under a curve

function AUC = ComputeAUC(x, y)

AUC = sum(((x(2:end)-x(1:end-1)).*(y(1:end-1)+y(2:end)))/2);

end