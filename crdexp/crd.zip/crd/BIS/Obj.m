%% Objective function value

function ObjVal = Obj(ia1, ia2, Anz, ib1, ib2, Bnz, ic1, ic2, Wnz, U, s, alpha, beta)

J1 = sum(bsxfun(@rdivide, sp_factor(ia1, ia2, U, U'), sum(U,1)+eps),2);
J1 = -(Anz')*log(J1+eps);

J2 = log(U+eps);
J2 = -(alpha-1)*sum(J2(:));

Us = bsxfun(@times, U, (s'));

J3 = sum(sp_factor(ib1, ib2, Us, U'),2);
J3 = -beta*(Bnz')*log(J3+eps);

J4 = sum(sp_factor(ic1, ic2, Us, U'),2);
J4 = beta*(Wnz')*J4;

ObjVal = J1 + J2 + J3 + J4;

end