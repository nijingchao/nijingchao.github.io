function PreRec=PrecisionRecall(BenchMark,returnedList)

% given the returned list, output recall and precision
numEle=length(returnedList);
hit=0;
for i=1:numEle
    Ele_i=returnedList(i);
    index_i= BenchMark==Ele_i;
    if any(index_i)
        hit=hit+1;
    end
end
recall=hit/length(BenchMark);
precision=hit/numEle;

PreRec=[precision,recall];


end