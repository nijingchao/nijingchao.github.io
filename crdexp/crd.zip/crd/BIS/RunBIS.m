%% Run on BIS data

function RunBIS

%% dataset

NetIDs = [120, 122];
Len = length(NetIDs);
RankLists = cell(Len,1);

%% Compile
% This step requries a C compiler

mex -largeArrayDims sp_factor.c
mex -largeArrayDims sp_factor_ratio.c

%% Run CRD

for i = 1:Len
    
    load(['Nets' num2str(NetIDs(i)) '.mat']);
    totaln = length(NodeNames);
    
    disp(['Run CRD on BIS network ' num2str(NetIDs(i)) ' ...']);
    
    [U, s, E, ~, ~, ~] = RunCRD(A, B);

    e = zeros(totaln,1);
    e(AllNodeIDs) = (U.*E)*s;
    [~, RankList_i] = sort(e,'descend');
    [~,diffidx] = setdiff(RankList_i,AllNodeIDs);
    RankList_i(diffidx) = [];
    RankLists{i} = RankList_i;
    
end

%% Evaluation

disp('Evaluation starts ...');

NumAbnorSignal = length(RankedBenchmark);
Thres = 2*NumAbnorSignal;
MaxP = length(RankedBenchmark);

for i = 1:Len
    
    RankList_i = RankLists{i};
    
    % PRAUC
    
    PreRec = zeros(Thres,2);
    
    for j = 1:Thres
        PreRec(j,:) = PrecisionRecall(RankedBenchmark,RankList_i(1:j));
    end
    
    PRAUC = ComputeAUC(PreRec(:,2), PreRec(:,1));
    
    % nDCG
    
    [NDCGval, ~] = NDCG(RankedBenchmark, AbnDegreeBench, RankList_i, MaxP);
    
    % Display AUC and nDCG values
    
    fprintf('The PRAUC on BIS network %d is %.4f.\n', NetIDs(i), PRAUC);
    fprintf('The nDCG on BIS network %d is %.4f.\n', NetIDs(i), NDCGval);
    
end

end