%% Run CRD algorithm

function [U, s, E, Js1, Js2, Js3] = RunCRD(A, B)

%% Initialization

n = size(A,1);
k = 7;
alpha = 1.1;
beta = 0.2;
c = 0.8;
tau = 1;
MaxIter = 500;
epsilon = 1e-3;

%% ClusAL

% First stage

W = (A>0) & (B==0);
[U, s, Js1, Deltas1, Iter1] = CRD_P1(A, B, W, alpha, beta, n, k, MaxIter, epsilon);

% Second stage

[H, Js2, Deltas2, Iter2] = UpdateH(A, c, n, MaxIter, epsilon);

% Js2 = 0;
% da = (sum(A,2)+eps).^(-0.5);
% Anorm = bsxfun(@times, A, da);
% Anorm = bsxfun(@times, Anorm, da');
% H = (1-c)*inv(speye(n,n) - c*Anorm);

C = A>0;
[E, Js3, Deltas3, Iter3] = CRD_P2(H, B, C, U, tau, n, k, MaxIter, epsilon);

end