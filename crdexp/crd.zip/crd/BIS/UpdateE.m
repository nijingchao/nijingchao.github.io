function Enew = UpdateE(B, P, M, U, E, tau)

%% Initialization

UE = U.*E;
BUE = B*UE;

PM = P.*M;
Num = PM*BUE;
Num = 4*(((B')*Num).*U);

% Num = ((B')*P).*M;
% Num = 4*((Num*BUE).*U);

Denom = M.*(BUE*(BUE'));
Denom = Denom*BUE;
Denom = 4*(((B')*Denom).*U) + tau;

% Denom = (B')*(BUE*(BUE'));
% Denom = 4*(((Denom.*M)*BUE).*U) + tau;

%% Updating

Enew = E.*((Num./(Denom+eps)).^(0.25));
% Enew=E.*gsqrt(gsqrt(gdivide(Num,Denom)));

end