%% Update H

function [Hnew, Js, Deltas, Iter] = UpdateH(A, c, n, MaxIter, epsilon)

%% Initialization

da = (sum(A,2)+eps).^(-0.5);
Anorm = bsxfun(@times, A, da);
Anorm = bsxfun(@times, Anorm, da');

In = speye(n,n);
Hnew = In;

Iter = 1;
% J1 = Obj(Anorm, In, Hnew, c);
J1 = 0;
Js = J1;
Delta = 99999;
Deltas = [];

%% Iteration

while Delta > epsilon && Iter <= MaxIter
    
    % Update H
    
    H = Hnew;
    Hnew = c*Anorm*Hnew + (1-c)*In;
    
    % Convergence evaluation
    
%     J2 = Obj(Anorm, In, Hnew, c);
%     Delta = J1 - J2;
%     Js = [Js, J2];
%     J1 = J2;
    
    Delta = abs(Hnew-H);
    Delta = sum(Delta(:));
    
    Deltas = [Deltas, Delta];
    Iter = Iter + 1;
    
end

end

% %% Objective function
% 
% function ObjVal = Obj(Anorm, In, H, c)
% 
% ObjVal = c*trace((H')*((In-Anorm)*H)) + (1-c)*norm(H-In,'fro')^2;
% 
% end