%% Update s in one iteration

function snew = UpdateS(B, W, U, s, beta)

%% Initialization

Y = sp_factor_ratio(B, bsxfun(@times, U, (s')), (U'));

YU = Y*U;
UYU = (U')*YU;
UYU_diag = diag(UYU);

WU = W*U;
UWU = (U')*WU;
UWU_diag = diag(UWU);

s_inv = 1./(s+eps);

Nabla_p = beta*UWU_diag + s_inv;
Nabla_n = beta*UYU_diag + s_inv;

%% Updating

snew = s.*((Nabla_n)./(Nabla_p+eps));
snew = min(snew, 1);

end