%% Update U in one iteration

function Unew = UpdateU(A, B, W, U, s, alpha, beta)

%% Initialization

h = sum(U,1);
h_inv = 1./(h+eps);

Z = sp_factor_ratio(A, bsxfun(@times, U, h_inv), (U'));
Y = sp_factor_ratio(B, bsxfun(@times, U, (s')), (U'));

ZU = Z*U;
UZU = (U')*ZU;
UZU_diag = diag(UZU);

YU = Y*U;
WU = W*U;

U_inv = 1./(U+eps);

Nabla_p = U_inv + 2*beta*bsxfun(@times, WU, (s'));
Nabla_p = bsxfun(@plus, (UZU_diag').*(h_inv.^2), Nabla_p);
Nabla_n = alpha*U_inv + 2*beta*bsxfun(@times, YU, (s'));
Nabla_n = 2*bsxfun(@times, ZU, h_inv) + Nabla_n;

a = U./(Nabla_p+eps);
a = sum(a,2);

b = U.*(Nabla_n./(Nabla_p+eps));
b = sum(b,2);

%% Updating

Unew = U.*((bsxfun(@times, a, Nabla_n) + 1)./(bsxfun(@plus, bsxfun(@times, a, Nabla_p), b) + eps));

end