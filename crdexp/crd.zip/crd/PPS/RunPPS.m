%% Run on PPS data

function RunPPS

%% datasets

NetIDs = [5732, 5940, 6080, 6950];
Len = length(NetIDs);
RankLists = cell(Len,1);

%% Compile
% This step requries a C compiler

mex -largeArrayDims sp_factor.c
mex -largeArrayDims sp_factor_ratio.c

%% Run CRD

for i = 1:Len
    
    load(['Nets' num2str(NetIDs(i)) '.mat']);
    
    disp(['Run CRD on PPS network ' num2str(NetIDs(i)) ' ...']);
    
    [U, s, E, ~, ~, ~] = RunCRD(A, B);
    
    e = (U.*E)*s;
    [~, RankList_i] = sort(e,'descend');
    RankLists{i} = RankList_i;
    
end

%% Evaluation

disp('Evaluation starts ...');

NumAbnorSignal = length(RankedBenchmark);
Thres = 2*NumAbnorSignal;
MaxP = length(RankedBenchmark);

for i = 1:Len
    
    RankList_i = RankLists{i};
    
    % PRAUC
    
    PreRec = zeros(Thres,2);
    
    for j = 1:Thres
        PreRec(j,:) = PrecisionRecall(RankedBenchmark,RankList_i(1:j));
    end

    PRAUC = ComputeAUC(PreRec(:,2), PreRec(:,1));
    
    % nDCG
    
    [NDCGval, ~] = NDCG(RankedBenchmark, AbnDegreeBench, RankList_i, MaxP);
    
    % Display AUC and nDCG values
    
    fprintf('The PRAUC on PPS network %d is %.4f.\n', NetIDs(i), PRAUC);
    fprintf('The nDCG on PPS network %d is %.4f.\n', NetIDs(i), NDCGval);
    
end

end