# Identifying Multiple Causal Anomalies by Modeling Local Propagations

This is a demo program of CRD.

## Contents

* BIS: the evaluation on BIS dataset.
* PPS: the evaluation on PPS dataset.

## Data

* Nets120.mat and Nets122.mat are BIS datasets with broken networks at time points 120 and 122. In the invariant networks, singleton nodes are removed.
* Nets5732.mat, Nets5940.mat, Nets6080.mat and Nets6950.mat are PPS datasets with broken networks at time points 5732, 5940, 6080 and 6950.

## Requirements

* All codes are tested using MATLAB R2015b.
* Some C codes require a C compiler.

## Running

* Run RunBIS.m for the evaluation on BIS dataset.
* Run RunPPS.m for the evaluation on PPS dataset.