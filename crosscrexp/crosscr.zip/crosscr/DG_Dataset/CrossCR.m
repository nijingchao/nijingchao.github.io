%% CrossCR alternating minimization on two networks

function [U1, U2, S12, S21, Deltas, Iter] = CrossCR(A1, A2, B12nrm, B21nrm, n1, n2, k1, k2, alpha, beta, MaxIter, epsilon, RandSeed)

%% Initialization

rand('seed',RandSeed);

% Initialize U

U1new = rand(n1,k1);
U1new = bsxfun(@rdivide, U1new, sum(U1new,2)+eps);

U2new = rand(n2,k2);
U2new = bsxfun(@rdivide, U2new, sum(U2new,2)+eps);

% Initialize S

S12new = rand(k1,k2);
S12new = bsxfun(@rdivide, S12new, sum(S12new,2)+eps);

S21new = rand(k2,k1);
S21new = bsxfun(@rdivide, S21new, sum(S21new,2)+eps);

% Convergence parameters

Delta = 99999;
Deltas = [];
Iter = 1;

%% Iterations

while Delta > epsilon && Iter <= MaxIter
    
    % Update U
    
    U1 = U1new;
    U1new = UpdateU(A1, U1new, U2new, S12new, S21new, B12nrm, B21nrm, alpha, beta);
    
    U2 = U2new;
    U2new = UpdateU(A2, U2new, U1new, S21new, S12new, B21nrm, B12nrm, alpha, beta);
    
    % Update S
    
    S12 = S12new;
    S12new = UpdateS(U1new, U2new, S12new, B12nrm, beta);
    
    S21 = S21new;
    S21new = UpdateS(U2new, U1new, S21new, B21nrm, beta);
    
    % Convergence evaluation
    
    Delta = zeros(4,1);
    
    Diff = abs(U1new - U1);
    Delta(1) = sum(Diff(:));
    
    Diff = abs(U2new - U2);
    Delta(2) = sum(Diff(:));
    
    Diff = abs(S12new - S12);
    Delta(3) = sum(Diff(:));
    
    Diff = abs(S21new - S21);
    Delta(4) = sum(Diff(:));
    
    Delta = max(Delta);
    
    Deltas = [Deltas, Delta];
    
    Iter = Iter + 1;
    
end

U1 = U1new;
U2 = U2new;
S12 = S12new;
S21 = S21new;

end