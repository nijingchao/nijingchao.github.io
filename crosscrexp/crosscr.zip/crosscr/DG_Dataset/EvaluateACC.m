%% Evaluate the accuracy of clustering

function [AvgACC_u, AllACCs_u] = EvaluateACC(Us, Us_idx, A_Labels, SizeThres)

%% Initialization

if isempty(Us_idx)
    
    g = length(Us);
    Us_idx = cell(g,1);
    
    for i = 1:g
        
        U_i = Us{i};
        [Vals, U_i_idx] = max(U_i, [], 2);
        Us_idx{i} = U_i_idx;
        
    end
    
else
    
    g = length(Us_idx);
    
end

%% ACC evaluation

Correct_u = zeros(g,1);
Total_u = zeros(g,1);
Counters_u = zeros(g,1);
AllACCs_u = cell(g,1);

for i = 1:g
    
    U_i_idx = Us_idx{i};
    A_Label_i = A_Labels{i};
    
    NonNoise_idx = A_Label_i > 0;
    A_Label_i = A_Label_i(NonNoise_idx);
    U_i_idx = U_i_idx(NonNoise_idx);
    
    % ACC evaluation
    
    U_Label_i = unique(U_i_idx);
    H_i = length(U_Label_i);
    
    AllACCs_u_i = zeros(H_i,1);
    
    for j = 1:H_i
        
        C_ij = A_Label_i(U_i_idx == U_Label_i(j));
        
        if length(C_ij) >= SizeThres
            
            [Maj, Freq] = mode(C_ij);
            Correct_u(i) = Correct_u(i) + Freq;
            Total_u(i) = Total_u(i) + length(C_ij);
            
            Counters_u(i) = Counters_u(i) + 1;
            
            AllACCs_u_i(j) = Freq/length(C_ij);
            
        else
            
            AllACCs_u_i(j) = -1;
            
        end
        
    end
    
    AllACCs_u_i = AllACCs_u_i(AllACCs_u_i >= 0);
    AllACCs_u{i} = AllACCs_u_i;
    
end

AvgACC_u = sum(Correct_u)/sum(Total_u);

end