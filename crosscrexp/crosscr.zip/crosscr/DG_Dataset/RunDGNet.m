%% Run a method on the DGNet

function RunDGNet

%% Initialization

SizeThres = 10; % The threshold of the minimum size of clusters to consider

%% Load data

load('DG_Nets.mat');

n1 = size(D_Net,1);
n2 = size(G_Net,1);

%% Compile
% This step requries a C compiler

mex -largeArrayDims sp_factor.c
mex -largeArrayDims sp_factor_ratio.c

%% Run the method

disp('CrossCR starts ...');

[U1, U2, S12, S21] = RunCrossCR(D_Net, G_Net, A_Net, A_Net', n1, n2);

% Accuracy evaluation

D_Labels = {D_Label};
[AvgACC_u, ~] = EvaluateACC({U1}, [], D_Labels, SizeThres);

ACC_d = AvgACC_u;

G_Labels = {G_Label};
[AvgACC_u, ~] = EvaluateACC({U2}, [], G_Labels, SizeThres);

ACC_g = AvgACC_u;

%% Display results

disp('======= Performance results on disease-gene network =======');
fprintf('disease cluster accuracy: %.4f\n', ACC_d);
fprintf('gene cluster accuracy: %.4f\n', ACC_g);

end