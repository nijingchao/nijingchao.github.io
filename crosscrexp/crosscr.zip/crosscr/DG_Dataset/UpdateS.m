%% Update S in one interation

function S_ij_new = UpdateS(U_i, U_j, S_ij, B_ij_nrm, beta)

%% Initialization

% Construct Y_ij

Y_ij = B_ij_nrm*U_j;
US_ij = U_i*S_ij;
Y_ij = Y_ij./(US_ij + eps);

%% Update S

Nabla_pos = 1./(S_ij + eps);
Nabla_neg = beta*((U_i')*Y_ij) + Nabla_pos;

c_ij = S_ij./(Nabla_pos + eps);
c_ij = sum(c_ij,2);

d_ij = S_ij.*(Nabla_neg./(Nabla_pos + eps));
d_ij = sum(d_ij,2);

S_ij_new = S_ij.*((bsxfun(@times, c_ij, Nabla_neg) + 1)./(bsxfun(@plus, bsxfun(@times, c_ij, Nabla_pos), d_ij) + eps));

end