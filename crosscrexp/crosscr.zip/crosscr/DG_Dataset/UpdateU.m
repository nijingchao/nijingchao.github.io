%% Update U_i in one interation

function U_i_new = UpdateU(A_i, U_i, U_j, S_ij, S_ji, B_ij_nrm, B_ji_nrm, alpha, beta)

%% Initialization

% Construct s_i

s_i = sum(U_i,1);
inv_s_i = 1./(s_i+eps);

% Construct W_i

W_i = sp_factor_ratio(A_i, bsxfun(@times, U_i, inv_s_i), (U_i'));

% Construct Y_ij

Y_ij = B_ij_nrm*U_j;
US_ij = U_i*S_ij;
Y_ij = Y_ij./(US_ij + eps);
Y_ij = Y_ij*(S_ij');

% Construct Q_ji

Q_ji = U_j*S_ji;
Q_ji = log(Q_ji + eps);
Q_ji = (B_ji_nrm')*Q_ji;

%% Update U_i

WU_i = W_i*U_i;
diag_UWU_i = diag((U_i')*WU_i)';

inv_U_i = 1./(U_i + eps);

Nabla_pos = bsxfun(@plus, diag_UWU_i.*(inv_s_i.^2), inv_U_i) - beta*Q_ji;
Nabla_neg = 2*bsxfun(@times, WU_i, inv_s_i) + alpha*inv_U_i + beta*Y_ij;

a_i = U_i./(Nabla_pos + eps);
a_i = sum(a_i,2);

b_i = U_i.*(Nabla_neg./(Nabla_pos + eps));
b_i = sum(b_i,2);

U_i_new = U_i.*((bsxfun(@times, a_i, Nabla_neg) + 1)./(bsxfun(@plus, bsxfun(@times, a_i, Nabla_pos), b_i) + eps));

end