%% Evaluate cluster ranking using medical log

function Hit = EvaluateClusRank_Clin(U1, U2, S12, S_Clin_IDs, D_Clin_IDs, TopK)

%% Cluster memberships

[~, U1_idx] = max(U1, [], 2);
[~, U2_idx] = max(U2, [], 2);

k1 = size(U1,2);
k2 = size(U2,2);

U1_clus = cell(k1,1);
U2_clus = cell(k2,1);

for i = 1:k1
    U1_clus{i} = find(U1_idx==i);
end

for i = 1:k2
    U2_clus{i} = find(U2_idx==i);
end

%% Evaluation

len = length(S_Clin_IDs);
Hit = 0;

for i = 1:len
    
    S_i = S_Clin_IDs{i};
    D_i = D_Clin_IDs{i};
    Jaccs_s = zeros(k1,1);
    
    S_i = unique(S_i,'stable');
    
    for j = 1:k1
        Jaccs_s(j) = length(intersect(S_i, U1_clus{j}))/(length(S_i)*length(U1_clus{j}));
    end
    
    [~, idx_s] = max(Jaccs_s);
    
    % extend D_i using semantically similar names
    
    D_i = unique(D_i,'stable');
    
    TmpS12 = S12;
    for j = 1:TopK
        [~, idx_d] = max(TmpS12(idx_s,:));
        numerator = 0;
        if length(intersect(D_i, U2_clus{idx_d})) >= 1
            numerator = numerator + 1;
        end
        overlaprate = numerator/length(D_i);
        
        if overlaprate >= 0.5 && length(U2_clus{idx_d}) < 3000 % remove large clusters
            Hit = Hit + 1;
            break;
        end
        TmpS12(idx_s,idx_d) = -1;
    end
    
end

end