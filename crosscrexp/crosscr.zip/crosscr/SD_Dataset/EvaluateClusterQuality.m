%% Evaluate the conductance of clustering

function [Conds, AllConds, AvgCond] = EvaluateClusterQuality(As, Us, Us_idx, SizeThres)

%% Initialization

if isempty(Us_idx)
    
    g = length(Us);
    Us_idx = cell(g,1);
    
    for i = 1:g
        
        U_i = Us{i};
        [Vals, U_i_idx] = max(U_i, [], 2);
        Us_idx{i} = U_i_idx;
        
    end
    
else
    
    g = length(Us_idx);
    
end

%% Conductance and density evaluation

Conds = zeros(g,1);
AllConds = cell(g,1);

TotalCond = 0;
TotalCondCounter = 0;

for i = 1:g
    
    A_i = As{i};
    A_i = triu(A_i);
    Vol_A_i = 2*sum(A_i(:));
    
    U_i_idx = Us_idx{i};
    U_Label_i = unique(U_i_idx);
    H_i = length(U_Label_i);
    
    Cond_i = zeros(H_i,1);
    
    for j = 1:H_i
        
        C_ij = U_i_idx == U_Label_i(j);
        n_c = length(find(C_ij)); % The number of nodes in cluster C_ij
        
        if n_c >= SizeThres
            
            SubA_ij = A_i(C_ij,C_ij');
            D_SubA_ij = A_i(C_ij,:);
            Vol_ij = sum(D_SubA_ij(:)) + sum(SubA_ij(:));
            
            m_c = sum(SubA_ij(:)); % The weights of edges in cluster C_ij
            s_c = Vol_ij - 2*m_c; % The weights of edges on the boundary of C_ij
            Vol_ij_bar = Vol_A_i - Vol_ij;
            
            % Conductance
            
            if Vol_ij == 0 || Vol_ij_bar == 0
                
                Cond_i(j) = -1;
                
            else
                
                Cond_i(j) = s_c/min(Vol_ij,Vol_ij_bar);
                
            end
            
        else
            
            Cond_i(j) = -1;
            
        end
        
    end
    
    Cond_i = Cond_i(Cond_i >= 0);
    Conds(i) = sum(Cond_i)/length(Cond_i);
    
    AllConds{i} = Cond_i;
    
    TotalCond = TotalCond + sum(Cond_i);
    TotalCondCounter = TotalCondCounter + length(Cond_i);
    
end

AvgCond = TotalCond/TotalCondCounter;

end