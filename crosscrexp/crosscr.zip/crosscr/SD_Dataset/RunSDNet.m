%% Run a method on the SDNet

function RunSDNet

%% Initialization

SizeThres = 10; % The threshold of the minimum size of clusters to consider
TopK = 10; % Rank threshold for the evaluation on medical log

%% Load data

load('SD_Nets.mat');

As = {S_Net; D_Net};
n1 = size(S_Net,1);
n2 = size(D_Net,1);

%% Compile
% This step requries a C compiler

mex -largeArrayDims sp_factor.c
mex -largeArrayDims sp_factor_ratio.c

%% Run CrossCR and evaluation
    
disp('CrossCR starts ...');

[U1, U2, S12, S21] = RunCrossCR(S_Net, D_Net, A_Net, A_Net', n1, n2);

Us = {U1; U2};

% Accuracy evaluation

D_Labels = {D_Lv2_Class};
[AvgACC_u, ~] = EvaluateACC({U2}, [], D_Labels, SizeThres);

ACC_Lv2 = AvgACC_u;

D_Labels = {D_Lv1_Class};
[AvgACC_u, ~] = EvaluateACC({U2}, [], D_Labels, SizeThres);

ACC_Lv1 = AvgACC_u;

% Conductance evaluation

[Conds_tmp, ~, ~] = EvaluateClusterQuality(As, Us, [], SizeThres);

Cond_1 = Conds_tmp(1);
Cond_2 = Conds_tmp(2);

% Medical log evaluation

Hit = EvaluateClusRank_Clin(U1, U2, S12, S_Clin_IDs, D_Clin_IDs, TopK);

%% Display results

disp('======= Performance results on symptom-disease network =======');
fprintf('Level 1 accuracy: %.4f\n', ACC_Lv1);
fprintf('Level 2 accuracy: %.4f\n', ACC_Lv2);
fprintf('Symptom network conductance: %.4f\n', Cond_1);
fprintf('Disease network conductance: %.4f\n', Cond_2);
fprintf('Recall of medical log hits at top %d rank: %.4f\n', TopK, Hit/length(S_Clin_IDs));

end