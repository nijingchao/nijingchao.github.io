%% Order S according to ground truth

function [S12_order, S21_order] = AlignCluster(U1, U2, S12, S21, A1_Label, A2_Label)

%% A1

[~, U1Membership] = max(U1,[],2);

U1Label = unique(U1Membership);
nClass1 = length(U1Label);
TrueLabel1 = unique(A1_Label);
nTrueClass1 = length(TrueLabel1);

G1 = zeros(nClass1,nTrueClass1);

for p=1:nClass1
    
    for q=1:nTrueClass1
        
        G1(p,q) = sum(U1Membership == U1Label(p) & A1_Label == TrueLabel1(q));
        
    end
    
end

[~, A1Idx] = max(G1,[],1);

%% A2

[~, U2Membership] = max(U2,[],2);

U2Label = unique(U2Membership);
nClass2 = length(U2Label);
TrueLabel2 = unique(A2_Label);
nTrueClass2 = length(TrueLabel2);

G2 = zeros(nClass2,nTrueClass2);

for p=1:nClass2
    
    for q=1:nTrueClass2
        
        G2(p,q) = sum(U2Membership == U2Label(p) & A2_Label == TrueLabel2(q));
        
    end
    
end

[~, A2Idx] = max(G2,[],1);

%% Order S12 and S21

S12_order = S12(A1Idx',A2Idx);
S21_order = S21(A2Idx',A1Idx);

end