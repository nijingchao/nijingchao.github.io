%% Evaluate clustering performance using NMI

function [NMIs_u, AvgNMI_u] = EvaluateNet(Us, Us_idx, A_Labels)

%% Initialization

if isempty(Us_idx)
    
    g = length(Us);
    Us_idx = cell(g,1);
    
    for i = 1:g
        
        U_i = Us{i};
        [Vals, U_i_idx] = max(U_i, [], 2);
        Us_idx{i} = U_i_idx;
        
    end
    
else
    
    g = length(Us_idx);
    
end

%% NMI evaluation

NMIs_u = zeros(g,1);

for i = 1:g
    
    U_i_idx = Us_idx{i};
    A_Label_i = A_Labels{i};
    
    NonNoise_idx = A_Label_i > 0;
    A_Label_i = A_Label_i(NonNoise_idx);
    U_i_idx = U_i_idx(NonNoise_idx);
    
    % NMI evaluation
    
    NMI_u_i = MutualInfo_modify(A_Label_i, U_i_idx);
    NMIs_u(i) = NMI_u_i;
    
end

AvgNMI_u = mean(NMIs_u);

end