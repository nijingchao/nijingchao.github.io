%% Generate rank labels

function Sij_Label = GenClusRank(Sij, ki)

% %% Normalization 
% 
% DSij = sum(Sij,2);
% Sij = bsxfun(@rdivide, Sij, DSij+eps);

%% Rank label

Sij_Label = [];

for p = 1:ki
    
    Sij_p = Sij(p,:);
    Len_p = length(Sij_p);
    
    % Sort
    
    [~, Sij_p_sort] = sort(Sij_p,'descend');
    Sij_p_rank = zeros(Len_p,1);
    Sij_p_rank(Sij_p_sort) = 1:Len_p;
    
    % Record label
    
    Sij_Label = [Sij_Label; Sij_p_rank];
    
end

end