%% AUC

function [TPR, FPR, AUC] = ROC_AUC(R, L)

%%% Input
% R: a vector of ranks
% L: a vector of binary labels

%% Initialization

MaxRank = max(R);
L_neg = ~L;
TPR = zeros(MaxRank,1);
FPR = zeros(MaxRank,1);

%% TPR FPR

for i = 1:MaxRank
    
    R_Idx = R <= i;
    TPR_i = sum(R_Idx & L)/(sum(L)+eps);
    FPR_i = sum(R_Idx & L_neg)/(sum(L_neg)+eps);
    TPR(i) = TPR_i;
    FPR(i) = FPR_i;
    
end

%% AUC

AUC = sum(((FPR(2:end)-FPR(1:end-1)).*(TPR(1:end-1)+TPR(2:end)))/2);

end