%% Run CrossCR

function [U1, U2, S12, S21] = RunCrossCR(A1, A2, B12, B21, n1, n2, k1, k2, RandSeed)

%% Initialization

alpha = 1.1;
beta = 3;
MaxIter = 1000; % The maximal number of inner iterations
epsilon = 1e-3; % The convergence parameter

% Normalize the association network

B12nrm = bsxfun(@rdivide, B12, sum(B12,2)+eps);
B21nrm = bsxfun(@rdivide, B21, sum(B21,2)+eps);

%% CrossCR

[U1, U2, S12, S21, Deltas, Iter] = CrossCR(A1, A2, B12nrm, B21nrm, n1, n2, k1, k2, alpha, beta, MaxIter, epsilon, RandSeed);

end