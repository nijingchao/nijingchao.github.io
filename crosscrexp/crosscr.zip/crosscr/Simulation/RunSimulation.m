%% Simulation

function RunSimulation

%% Initialization

g = 1; % Number of runs, range in [1:100] for 100 different synthetic networks
RandSeeds = 100*(1:g);
NMIs1 = zeros(g,1);
NMIs2 = zeros(g,1);
S12_Labels = [];
S21_Labels = [];
TrueS12_Labels = [];
TrueS21_Labels = [];

%% Load dataset

load('SynNets_mu04_Dnst003.mat');

%% Compile
% This step requries a C compiler

mex -largeArrayDims sp_factor.c
mex -largeArrayDims sp_factor_ratio.c

%% Run on synthetic networks

for i = 1:g
    
    A1 = A1s{i};
    A2 = A2s{i};
    B = Bs{i};
    TrueS = TrueSs{i};
    A1_Label = A1_Labels{i};
    A2_Label = A2_Labels{i};
    A_Labels = {A1_Label; A2_Label};
    n1 = length(A1_Label);
    n2 = length(A2_Label);
    k1 = max(A1_Label);
    k2 = max(A2_Label);
    
    % True labels
    
    IdxMat = TrueS > 0;
    TrueS12_Labels = [TrueS12_Labels; reshape(IdxMat',[k1*k2,1])];
    TrueS21_Labels = [TrueS21_Labels; reshape(IdxMat,[k1*k2,1])];
    
    % CrossCR
    
    disp('CrossCR starts ...');
    
    [U1, U2, S12, S21] = RunCrossCR(A1, A2, B, B', n1, n2, k1, k2, RandSeeds(i));
    
    Us = {U1; U2};
    
    % Evaluate clustering performance
    
    [NMIs_u, ~] = EvaluateNet(Us, [], A_Labels);
    
    NMIs1(i) = NMIs_u(1);
    NMIs2(i) = NMIs_u(2);
    
    % Align computed cluster with ground truth
    
    [S12_order, S21_order] = AlignCluster(U1, U2, S12, S21, A1_Label, A2_Label);
    
    % Generate rank label
    
    S12_Label = GenClusRank(S12_order, k1);
    S21_Label = GenClusRank(S21_order, k2);
    
    S12_Labels = [S12_Labels; S12_Label];
    S21_Labels = [S21_Labels; S21_Label];
    
end

AvgNMI1 = mean(NMIs1,2);
AvgNMI2 = mean(NMIs2,2);

[~, ~, AUC12] = ROC_AUC(S12_Labels, TrueS12_Labels);
[~, ~, AUC21] = ROC_AUC(S21_Labels, TrueS21_Labels);

%% Display results

disp('======= Performance results (mu=0.4, density=0.03) =======');
fprintf('Averged NMI: %.4f\n', mean([AvgNMI1,AvgNMI2]));
fprintf('Averged AUC: %.4f\n', mean([AUC12,AUC21]));

end